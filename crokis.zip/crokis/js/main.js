/* Croki's — contagem regressiva
   Para mudar a data, altere LANCAMENTO (o "-03:00" é o horário de Brasília). */
(function () {
  'use strict';

  var LANCAMENTO = Date.parse('2026-11-06T11:00:00-03:00');

  var el = {
    dias: document.getElementById('dias'),
    horas: document.getElementById('horas'),
    min: document.getElementById('min'),
    seg: document.getElementById('seg'),
    contador: document.getElementById('contador'),
    chegou: document.getElementById('chegou'),
    chamada: document.getElementById('chamada'),
    texto: document.getElementById('texto')
  };

  function dois(n) { return (n < 10 ? '0' : '') + n; }

  function atualizar() {
    var falta = Math.max(0, LANCAMENTO - Date.now());
    var s = Math.floor(falta / 1000);

    el.dias.textContent = dois(Math.floor(s / 86400));
    el.horas.textContent = dois(Math.floor((s % 86400) / 3600));
    el.min.textContent = dois(Math.floor((s % 3600) / 60));
    el.seg.textContent = dois(s % 60);

    if (falta === 0) {
      el.contador.hidden = true;
      el.chegou.hidden = false;
      el.chamada.textContent = 'Chegou a hora';
      el.texto.innerHTML = 'A Croki’s chegou! Corre no Instagram<br>pra ver tudo em primeira mão.';
      clearInterval(timer);
    }
  }

  var timer = setInterval(atualizar, 1000);
  atualizar();
})();
