# Croki's — página de contagem regressiva

- **Objetivo:** página temporária até o lançamento da marca
- **Lançamento:** 06/11/2026 às 11h (horário de Brasília)
- **Instagram:** @crokislovers
- **Cor da marca:** rosa #D42E60 · fonte Fredoka
- **Animação:** massa de chocolate sendo mexida + barra "mexendo a massa…"
- **Ao zerar:** o contador some, aparece "Saiu do forno!" e o convite para o Instagram

## Como editar
- Data/hora: `js/main.js`, constante `LANCAMENTO`
- Depois de publicar: colocar a URL completa em `og:image` e `og:url` no `index.html`
- Publicação só com o OK do João
